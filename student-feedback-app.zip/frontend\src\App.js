﻿import React, { useState, useEffect } from 'react';
import FeedbackForm from './components/FeedbackForm';
import FeedbackList from './components/FeedbackList';
import Dashboard from './components/Dashboard';
import { feedbackAPI } from './services/api';
import './styles/App.css';

function App() {
  const [activeTab, setActiveTab] = useState('form');
  const [refreshKey, setRefreshKey] = useState(0);
  const [backendStatus, setBackendStatus] = useState('checking');
  const [connectionError, setConnectionError] = useState('');

  const checkBackendConnection = async () => {
    try {
      setBackendStatus('checking');
      const response = await feedbackAPI.health();
      console.log('✅ Backend connection successful:', response.data);
      setBackendStatus('connected');
      setConnectionError('');
    } catch (error) {
      console.error('❌ Backend connection failed:', error.message);
      setBackendStatus('disconnected');
      setConnectionError(error.message);
    }
  };

  useEffect(() => {
    checkBackendConnection();
  }, []);

  const handleFeedbackAdded = () => {
    setRefreshKey(prev => prev + 1);
  };

  const getStatusIcon = () => {
    switch (backendStatus) {
      case 'connected': return '✅';
      case 'disconnected': return '❌';
      case 'checking': return '🔄';
      default: return '❓';
    }
  };

  const getStatusClass = () => {
    switch (backendStatus) {
      case 'connected': return 'status-connected';
      case 'disconnected': return 'status-disconnected';
      case 'checking': return 'status-checking';
      default: return '';
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>🎓 Student Feedback Portal</h1>
        
        <div className={`connection-status ${getStatusClass()}`}>
          <strong>Backend Status:</strong> {getStatusIcon()} {backendStatus.toUpperCase()}
          {backendStatus === 'disconnected' && (
            <button 
              onClick={checkBackendConnection}
              style={{
                marginLeft: '1rem',
                padding: '0.4rem 1rem',
                backgroundColor: 'rgba(255,255,255,0.2)',
                color: 'white',
                border: '1px solid rgba(255,255,255,0.3)',
                borderRadius: '8px',
                cursor: 'pointer',
                fontSize: '0.8rem',
                fontWeight: '600'
              }}
            >
              🔄 Retry Connection
            </button>
          )}
        </div>

        <nav>
          <button 
            className={activeTab === 'form' ? 'active' : ''}
            onClick={() => setActiveTab('form')}
          >
            📝 Submit Feedback
          </button>
          <button 
            className={activeTab === 'view' ? 'active' : ''}
            onClick={() => setActiveTab('view')}
          >
            👁️ View Feedback
          </button>
          <button 
            className={activeTab === 'dashboard' ? 'active' : ''}
            onClick={() => setActiveTab('dashboard')}
          >
            📊 Dashboard
          </button>
        </nav>
      </header>

      <main className="App-main">
        {backendStatus === 'disconnected' && (
          <div className="error">
            <h3>⚠️ Connection Issue Detected</h3>
            <p><strong>Problem:</strong> {connectionError || 'Cannot reach backend server'}</p>
            <div style={{ marginTop: '1rem', fontSize: '0.9rem' }}>
              <p><strong>Quick Fix:</strong></p>
              <ol>
                <li>Ensure backend is running on port 5001</li>
                <li>Check firewall settings</li>
                <li>Refresh the page after backend starts</li>
              </ol>
            </div>
          </div>
        )}
        
        {activeTab === 'form' && (
          <FeedbackForm onFeedbackAdded={handleFeedbackAdded} />
        )}
        {activeTab === 'view' && (
          <FeedbackList refresh={refreshKey} />
        )}
        {activeTab === 'dashboard' && (
          <Dashboard />
        )}
      </main>
    </div>
  );
}

export default App;